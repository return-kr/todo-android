package com.ristu.hometaskapp.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.ristu.hometaskapp.model.Person

@Database(entities = [Person::class], version = 2)
abstract class PersonDatabase : RoomDatabase() {
    abstract fun getPersonDao(): PersonDao
}