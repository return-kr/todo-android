package com.ristu.hometaskapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room.databaseBuilder
import com.ristu.hometaskapp.databinding.ActivityMainBinding
import com.ristu.hometaskapp.db.PersonDatabase
import com.ristu.hometaskapp.model.Person
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val logMessages = mutableListOf<Person>()
    private lateinit var adapter: PersonAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val db = synchronized(this) {
            databaseBuilder(
                applicationContext,
                PersonDatabase::class.java, "user-database"
            ).build()
        }
        val personDao = db.getPersonDao()
        binding.apply {
            onItemClick = View.OnClickListener { view ->
                when (view.id) {
                    R.id.insert_user_button -> {
                        lifecycleScope.launch(Dispatchers.IO) {
                            personDao.insertUser(
                                Person(
                                    firstName = firstName.text.toString(),
                                    lastName = lastName.text.toString(),
                                )
                            )
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    this@MainActivity,
                                    "User Inserted",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }

                    R.id.get_user_button -> {
                        lifecycleScope.launch(Dispatchers.IO) {
                            val result = personDao.getAll()
                            if (result.isEmpty()) {
                                val emptyPerson = Person(0, "", "")
                                updateRecyclerView(emptyPerson)
                            } else {
                                result.forEach {
                                    updateRecyclerView(it)
                                }
                            }

                        }
                    }

                }
            }
        }

        adapter = PersonAdapter(logMessages)
        binding.userRecyclerView.adapter = adapter
        binding.userRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun updateRecyclerView(person: Person) {
        lifecycleScope.launch(Dispatchers.Main) {
            logMessages.add(person)
            adapter.notifyDataSetChanged()
        }
    }
}