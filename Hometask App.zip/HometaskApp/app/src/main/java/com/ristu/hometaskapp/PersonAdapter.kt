package com.ristu.hometaskapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ristu.hometaskapp.databinding.PersonItemBinding
import com.ristu.hometaskapp.model.Person
import java.util.Locale

class PersonAdapter(private val itemList: List<Person>) :
    RecyclerView.Adapter<PersonAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: PersonItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Person) {
            binding.item = item
            binding.firstNameTextView.text = item.firstName?.uppercase(Locale.ROOT)
            binding.lastNameTextView.text = item.lastName?.lowercase(Locale.ROOT)
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = PersonItemBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = itemList[position]
        holder.bind(user)
    }


    override fun getItemCount() = itemList.size
}
