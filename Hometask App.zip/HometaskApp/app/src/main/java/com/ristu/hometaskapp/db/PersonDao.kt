package com.ristu.hometaskapp.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.ristu.hometaskapp.model.Person

@Dao
interface PersonDao {
    @Query("SELECT * FROM persons")
    fun getAll(): List<Person>

    @Query("SELECT * FROM persons WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray): List<Person>

    @Query("SELECT * FROM persons WHERE first_name LIKE :first AND " +
            "last_name LIKE :last LIMIT 1")
    fun findByName(first: String, last: String): Person

    @Insert
    fun insertUser(user: Person)

    @Delete
    fun delete(user: Person)
}